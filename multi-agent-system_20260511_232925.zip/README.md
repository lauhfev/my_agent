# 多Agent协同运营自动化系统

![Version](https://img.shields.io/badge/version-1.0.0-blue)
![Python](https://img.shields.io/badge/python-3.9+-green)
![License](https://img.shields.io/badge/license-MIT-yellow)

一个基于Python的多Agent协同运营自动化系统MVP，支持任务调度、内容生成、数据监控、报告生成和通知推送等功能。

## 📋 目录

- [功能特性](#功能特性)
- [系统架构](#系统架构)
- [快速开始](#快速开始)
- [使用指南](#使用指南)
- [API文档](#api文档)
- [配置说明](#配置说明)
- [Agent说明](#agent说明)
- [打包部署](#打包部署)
- [技术栈](#技术栈)
- [贡献指南](#贡献指南)
- [许可证](#许可证)

## ✨ 功能特性

- **多Agent协同框架**：基于消息总线的Agent通信机制，支持Agent动态注册和任务分配
- **任务调度管理**：支持定时任务、周期性任务和触发式任务的统一调度
- **运营自动化场景**：内容生成、数据监控、报告生成、通知推送等核心运营能力
- **Web可视化Dashboard**：实时查看Agent状态、任务执行情况、系统日志和性能指标
- **配置驱动**：YAML配置文件驱动系统行为，支持热加载
- **一键部署**：包含启动脚本和打包脚本，生成可独立运行的压缩包

## 🏗️ 系统架构

### 架构图

```
┌─────────────┐
│                    用户界面层                              │
│  ┌──────────────┐      ┌──────────────┐               │
│  │  Web Dashboard │      │   API Client  │               │
│  └──────┬───────┘      └──────┬───────┘               │
└─────────┼───────────────────────┼───────────────────────┘
          │                       │
          ▼                       ▼
┌─────────────┐
│                   服务层 (Services)                        │
│  ┌──────────────┐      ┌──────────────┐               │
│  │  Flask API   │      │  WebSocket   │               │
│  └──────┬───────┘      └──────┬───────┘               │
└─────────┼───────────────────────┼───────────────────────┘
          │                       │
          ▼                       ▼
┌─────────────┐
│                   Agent层 (Agents)                         │
│  ┌──────┐  ┌──────┐  ┌──────┐  ┌──────┐  ┌────────┐│
│  │Scheduler│  │Content│  │Monitor│  │Report│  │Notif.  ││
│  └──┬───┘  └──┬───┘  └──┬───┘  └──┬───┘  └───┬────┘│
└─────┼─────────┼─────────┼─────────┼─────────┼──────┘
      │         │         │         │         │
      ▼         ▼         ▼         ▼         ▼
┌─────────────┐
│                   核心框架层 (Core)                        │
│  ┌──────────┐  ┌──────────┐  ┌──────────┐           │
│  │Message Bus│  │Task Queue│  │Config Mgr │           │
│  └──────────┘  └──────────┘  └──────────┘           │
└─────────────┘
```

### 技术栈

- **后端框架**：Python 3.9+ + Flask 3.0 + SocketIO
- **Agent通信**：Redis Pub/Sub（可选） + 内存消息总线
- **任务调度**：APScheduler
- **数据处理**：Pandas + NumPy
- **配置管理**：PyYAML
- **日志系统**：Python logging + RotatingFileHandler
- **前端**：HTML + JavaScript + Tailwind CSS

## 🚀 快速开始

### 环境要求

- Python 3.9+
- pip（Python包管理器）

### 1. 克隆项目

```bash
git clone <repository-url>
cd multi-agent-system
```

### 2. 安装依赖

```bash
pip install -r requirements.txt
```

### 3. 启动系统

```bash
python scripts/start.py
```

### 4. 访问Dashboard

打开浏览器访问: http://localhost:5000

### 5. 停止系统

```bash
python scripts/stop.py
```

## 📖 使用指南

### 启动Agent

系统启动时会自动启动所有5个Agent：

1. **SchedulerAgent** - 任务调度器
2. **ContentAgent** - 内容生成器
3. **MonitorAgent** - 数据监控器
4. **ReportAgent** - 报告生成器
5. **NotificationAgent** - 通知推送器

### 创建任务

通过API创建任务：

```bash
curl -X POST http://localhost:5000/api/tasks \
  -H "Content-Type: application/json" \
  -d '{
    "task_type": "generate_content",
    "agent_name": "content",
    "payload": {
      "content_type": "post",
      "product": "多Agent系统"
    }
  }'
```

### 查看日志

日志文件位于 `logs/` 目录：

- `system.log` - 系统日志
- `agent.scheduler.log` - 调度器日志
- `agent.content.log` - 内容生成器日志
- 等等

### 监控指标

系统会自动监控以下指标：

- CPU使用率
- 内存使用率
- 磁盘使用率
- 响应时间
- 错误率

当指标超过阈值时，会自动发送通知。

## 📡 API文档

### 系统状态

**GET** `/api/status`

获取系统整体状态，包括Agent状态、任务统计等。

**响应示例：**
```json
{
  "success": true,
  "data": {
    "agents": [...],
    "tasks": {
      "total": 10,
      "pending": 2,
      "running": 1,
      "completed": 6,
      "failed": 1
    },
    "system_time": "2026-05-11T23:30:00"
  }
}
```

### Agent管理

**GET** `/api/agents`

获取所有Agent信息。

**POST** `/api/agents/{agent_name}/start`

启动指定Agent。

**POST** `/api/agents/{agent_name}/stop`

停止指定Agent。

### 任务管理

**GET** `/api/tasks`

获取所有任务列表。

**POST** `/api/tasks`

创建新任务。

**请求体：**
```json
{
  "task_type": "generate_content",
  "agent_name": "content",
  "priority": 2,
  "payload": {
    "content_type": "post",
    "product": "产品名称"
  }
}
```

**DELETE** `/api/tasks/{task_id}`

取消指定任务。

### 配置管理

**GET** `/api/config`

获取系统配置。

**PUT** `/api/config`

更新系统配置。

### 日志查询

**GET** `/api/logs`

获取系统日志（最近100行）。

## ⚙️ 配置说明

配置文件位于 `config/` 目录：

### system.yaml

系统主配置文件，包含：

- Web服务器配置（host, port, debug）
- 日志配置（level, console, file）
- Redis配置（可选）
- 性能配置（最大并发任务数、任务超时时间等）

### agents.yaml

Agent配置文件，包含每个Agent的：

- 是否启用
- 描述信息
- 特定配置参数（如监控间隔、报告类型等）

### tasks.yaml

预定义任务配置文件，包含：

- 调度任务列表（定时任务）
- 启动任务列表（系统启动时自动执行）

## 🤖 Agent说明

### SchedulerAgent（调度器Agent）

**功能**：负责任务分配和协调

**支持的任务类型**：
- `schedule_task` - 调度任务
- `cancel_scheduled_task` - 取消调度任务
- `list_scheduled_tasks` - 列出所有调度任务
- `list_agents` - 列出所有Agent

### ContentAgent（内容生成Agent）

**功能**：自动生成运营内容

**支持的内容类型**：
- `post` - 社交媒体帖子
- `article` - 文章
- `email` - 邮件
- `notification` - 通知消息

### MonitorAgent（数据监控Agent）

**功能**：监控系统指标和数据变化

**监控的指标**：
- CPU使用率
- 内存使用率
- 磁盘使用率
- 响应时间
- 错误率

**告警**：当指标超过阈值时自动发送通知

### ReportAgent（报告生成Agent）

**功能**：生成运营报告

**支持的报告类型**：
- `daily` - 每日报告
- `weekly` - 每周报告
- `monthly` - 每月报告
- `custom` - 自定义报告

### NotificationAgent（通知推送Agent）

**功能**：发送通知消息

**支持的通知类型**：
- `console` - 控制台输出
- `email` - 邮件通知
- `sms` - 短信通知
- `webhook` - Webhook通知

## 📦 打包部署

### 生成压缩包

运行打包脚本：

```bash
python scripts/package.py
```

脚本会生成 `multi-agent-system_YYYYMMDD_HHMMSS.zip` 文件，包含所有源代码和配置文件。

### 部署步骤

1. 将压缩包复制到目标服务器
2. 解压缩
3. 安装依赖：`pip install -r requirements.txt`
4. 启动系统：`python scripts/start.py`
5. 访问Dashboard：`http://服务器IP:5000`

## 🛠️ 技术栈

### 后端

- **Python 3.9+** - 编程语言
- **Flask 3.0** - Web框架
- **Flask-SocketIO** - WebSocket支持
- **APScheduler** - 任务调度
- **PyYAML** - YAML配置解析
- **Pandas/NumPy** - 数据处理

### 前端

- **HTML5** - 页面结构
- **JavaScript** - 交互逻辑
- **Tailwind CSS** - 样式框架
- **Socket.IO** - 实时通信

### 工具

- **Git** - 版本控制
- **pip** - 包管理

## 📝 开发指南

### 添加新Agent

1. 在 `agents/` 目录创建新Agent类
2. 继承 `BaseAgent` 基类
3. 实现 `initialize()`, `execute()`, `shutdown()` 方法
4. 在 `agents/__init__.py` 中导入新Agent
5. 在 `scripts/start.py` 中注册新Agent

**示例：**

```python
from .base_agent import BaseAgent, AgentStatus
from . import Task, task_queue, message_bus, Message, MessageType

class MyCustomAgent(BaseAgent):
    def __init__(self):
        super().__init__("myagent", "我的自定义Agent")
    
    async def initialize(self) -> None:
        self.logger.info("自定义Agent初始化")
        # 初始化代码
    
    async def execute(self, task: Task) -> Dict:
        self.logger.info(f"执行任务: {task.task_id}")
        # 执行任务代码
        return {"result": "成功"}
    
    async def shutdown(self) -> None:
        self.logger.info("自定义Agent关闭")
        # 清理代码
```

### 添加新API路由

在 `services/api_routes.py` 中添加新路由：

```python
@app.route('/api/my-endpoint', methods=['GET'])
def my_endpoint():
    return jsonify({
        'success': True,
        'data': {'message': 'Hello World'}
    })
```

### 修改配置

编辑 `config/system.yaml` 或 `config/agents.yaml`，然后重启系统。

## 🐛 故障排除

### 系统无法启动

**问题**：运行 `python scripts/start.py` 报错

**解决方案**：
1. 检查Python版本（需要3.9+）
2. 检查依赖是否安装：`pip install -r requirements.txt`
3. 查看日志文件：`logs/system.log`

### 端口被占用

**问题**：Web服务器启动失败，提示端口被占用

**解决方案**：
1. 修改 `config/system.yaml` 中的端口配置
2. 或者停止占用端口的进程

### Agent启动失败

**问题**：某个Agent无法启动

**解决方案**：
1. 查看该Agent的日志文件
2. 检查 `config/agents.yaml` 中的配置
3. 确保Agent依赖已安装

## 📄 许可证

本项目采用 MIT 许可证。详见 [LICENSE](LICENSE) 文件。

## 📧 联系方式

如有问题或建议，请提交Issue或联系我们。

---

**Made with ❤️ by Multi-Agent Team**
