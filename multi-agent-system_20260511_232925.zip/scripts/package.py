"""
打包脚本 - 生成可运行压缩包
"""
import os
import sys
import zipfile
from pathlib import Path
from datetime import datetime

# 添加项目根目录到Python路径
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from core import get_logger


logger = get_logger("package")


def create_zip_package(output_path: str = None, exclude_dirs: list = None):
    """创建ZIP压缩包"""
    
    if not output_path:
        timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
        output_path = project_root / f"multi-agent-system_{timestamp}.zip"
    
    if exclude_dirs is None:
        exclude_dirs = ['__pycache__', 'node_modules', '.git', 'venv', 'env', 'logs', 'data']
    
    logger.info(f"开始打包系统...")
    logger.info(f"输出路径: {output_path}")
    
    # 创建ZIP文件
    with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        # 遍历项目目录
        for root, dirs, files in os.walk(project_root):
            # 排除指定目录
            dirs[:] = [d for d in dirs if d not in exclude_dirs]
            
            for file in files:
                file_path = Path(root) / file
                
                # 排除.pyc文件和临时文件
                if file.endswith(('.pyc', '.pyo', '.tmp')):
                    continue
                
                # 计算相对路径
                arcname = file_path.relative_to(project_root)
                
                # 添加到ZIP
                zipf.write(file_path, arcname)
                logger.debug(f"已添加: {arcname}")
    
    # 获取文件大小
    size = Path(output_path).stat().st_size
    size_mb = size / (1024 * 1024)
    
    logger.info(f"打包完成!")
    logger.info(f"文件路径: {output_path}")
    logger.info(f"文件大小: {size_mb:.2f} MB")
    
    return output_path


def create_requirements_file():
    """创建requirements.txt文件"""
    requirements = [
        "flask==3.0.0",
        "flask-socketio==5.3.6",
        "flask-cors==4.0.0",
        "python-socketio==5.10.0",
        "apscheduler==3.10.4",
        "pyyaml==6.0.1",
        "pandas==2.1.4",
        "numpy==1.26.2",
        "werkzeug==3.0.1"
    ]
    
    requirements_file = project_root / "requirements.txt"
    
    with open(requirements_file, 'w', encoding='utf-8') as f:
        f.write('\n'.join(requirements))
    
    logger.info(f"requirements.txt已创建: {requirements_file}")
    
    return requirements_file


def create_readme():
    """创建README.md文件"""
    readme_content = """# 多Agent协同运营自动化系统

这是一个基于Python的多Agent协同运营自动化系统MVP，支持任务调度、内容生成、数据监控、报告生成和通知推送等功能。

## 功能特性

- **多Agent协同框架**：基于消息总线的Agent通信机制
- **任务调度管理**：支持定时任务、周期性任务和触发式任务
- **运营自动化**：内容生成、数据监控、报告生成、通知推送
- **Web可视化Dashboard**：实时查看Agent状态、任务执行情况
- **配置驱动**：YAML配置文件驱动系统行为
- **一键部署**：包含启动脚本和打包脚本

## 快速开始

### 1. 安装依赖

```bash
pip install -r requirements.txt
```

### 2. 启动系统

```bash
python scripts/start.py
```

### 3. 访问Dashboard

打开浏览器访问: http://localhost:5000

### 4. 停止系统

```bash
python scripts/stop.py
```

## 系统架构

- **Core Framework**: Agent基类、消息总线、任务队列、配置管理
- **Agent Layer**: 调度器、内容生成、监控、报告、通知5个Agent
- **Service Layer**: Web Dashboard、API服务、日志服务
- **Storage Layer**: 文件日志 + JSON数据存储

## 配置说明

配置文件位于 `config/` 目录：

- `system.yaml`: 系统主配置
- `agents.yaml`: Agent配置
- `tasks.yaml`: 预定义任务配置

## Agent说明

1. **SchedulerAgent**: 任务调度器，负责任务分配和协调
2. **ContentAgent**: 内容生成器，自动生成运营内容
3. **MonitorAgent**: 数据监控器，监控系统指标和数据变化
4. **ReportAgent**: 报告生成器，生成运营报告
5. **NotificationAgent**: 通知推送器，发送通知消息

## API接口

- `GET /api/status`: 获取系统状态
- `GET /api/agents`: 获取所有Agent信息
- `GET /api/tasks`: 获取所有任务
- `POST /api/tasks`: 创建新任务
- `GET /api/config`: 获取系统配置
- `GET /api/logs`: 获取系统日志

## WebSocket事件

- `connect`: 客户端连接
- `subscribe`: 订阅主题
- `unsubscribe`: 取消订阅
- `send_message`: 发送消息
- `status_update`: 状态更新
- `agents_update`: Agent更新

## 打包部署

运行打包脚本生成可部署的ZIP压缩包：

```bash
python scripts/package.py
```

生成的压缩包包含所有源代码和配置文件，可直接解压部署。

## 技术栈

- **后端**: Python 3.9+ / Flask 3.0 / SocketIO
- **Agent通信**: Redis Pub/Sub (可选) + 内存消息总线
- **任务调度**: APScheduler
- **数据处理**: Pandas / NumPy
- **配置管理**: PyYAML
- **日志系统**: Python logging + RotatingFileHandler

## 许可证

MIT License

## 联系方式

如有问题或建议，请提交Issue。
"""
    
    readme_file = project_root / "README.md"
    
    with open(readme_file, 'w', encoding='utf-8') as f:
        f.write(readme_content)
    
    logger.info(f"README.md已创建: {readme_file}")
    
    return readme_file


def main():
    """主函数"""
    logger.info("=" * 60)
    logger.info("多Agent系统打包工具")
    logger.info("=" * 60)
    
    # 创建requirements.txt
    create_requirements_file()
    
    # 创建README.md
    create_readme()
    
    # 创建ZIP压缩包
    output_path = create_zip_package()
    
    logger.info("打包完成!")
    logger.info(f"请查看: {output_path}")


if __name__ == '__main__':
    main()
