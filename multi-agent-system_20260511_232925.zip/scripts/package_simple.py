"""
简化的打包脚本 - 生成可运行压缩包
"""
import os
import zipfile
from pathlib import Path
from datetime import datetime
from typing import List, Set


def create_zip_package(
    project_root: Path,
    output_path: Path,
    exclude_dirs: Set[str],
    exclude_files: Set[str]
) -> Path:
    """
    创建ZIP压缩包
    
    Args:
        project_root: 项目根目录
        output_path: 输出ZIP文件路径
        exclude_dirs: 要排除的目录名集合
        exclude_files: 要排除的文件扩展名集合
    
    Returns:
        生成的ZIP文件路径
    """
    print(f"开始打包系统...")
    print(f"项目目录: {project_root}")
    print(f"输出路径: {output_path}")
    
    # 确保输出目录存在
    output_path.parent.mkdir(parents=True, exist_ok=True)
    
    # 创建ZIP文件
    with zipfile.ZipFile(output_path, 'w', zipfile.ZIP_DEFLATED) as zipf:
        # 遍历项目目录
        for root, dirs, files in os.walk(project_root):
            # 排除指定目录
            dirs[:] = [d for d in dirs if d not in exclude_dirs]
            
            for file in files:
                # 排除指定文件类型
                if any(file.endswith(ext) for ext in exclude_files):
                    continue
                
                # 排除输出文件自身
                file_path = Path(root) / file
                if file_path == output_path:
                    continue
                
                # 计算相对路径
                arcname = file_path.relative_to(project_root)
                
                # 添加到ZIP
                zipf.write(file_path, arcname)
                print(f"  已添加: {arcname}")
    
    # 获取文件大小
    size = output_path.stat().st_size
    size_mb = size / (1024 * 1024)
    
    print(f"\n打包完成!")
    print(f"文件路径: {output_path}")
    print(f"文件大小: {size_mb:.2f} MB")
    
    return output_path


def create_requirements():
    """创建requirements.txt文件"""
    requirements = [
        "flask==3.0.0",
        "flask-socketio==5.3.6",
        "flask-cors==4.0.0",
        "python-socketio==5.10.0",
        "apscheduler==3.10.4",
        "pyyaml==6.0.1",
        "pandas==2.1.4",
        "numpy==1.26.2",
        "werkzeug==3.0.1"
    ]
    
    project_root = Path(__file__).parent.parent
    requirements_file = project_root / "requirements.txt"
    
    with open(requirements_file, 'w', encoding='utf-8') as f:
        f.write('\n'.join(requirements))
    
    print(f"requirements.txt已创建: {requirements_file}")
    
    return requirements_file


def main():
    """主函数"""
    print("=" * 60)
    print("多Agent系统打包工具（简化版）")
    print("=" * 60)
    
    # 获取项目根目录
    project_root = Path(__file__).parent.parent
    
    # 创建requirements.txt
    create_requirements()
    
    # 创建README.md（如果不存在）
    readme_file = project_root / "README.md"
    if not readme_file.exists():
        print("README.md不存在，请先创建")
        return
    
    # 生成输出文件名
    timestamp = datetime.now().strftime('%Y%m%d_%H%M%S')
    output_path = project_root.parent / f"multi-agent-system_{timestamp}.zip"
    
    # 排除的目录和文件
    exclude_dirs = {
        '__pycache__',
        'node_modules',
        '.git',
        'venv',
        'env',
        'logs',
        'data',
        '.idea',
        '.vscode'
    }
    
    exclude_files = {
        '.pyc',
        '.pyo',
        '.tmp',
        '.log',
        '.zip'
    }
    
    # 创建压缩包
    try:
        output_path = create_zip_package(
            project_root=project_root,
            output_path=output_path,
            exclude_dirs=exclude_dirs,
            exclude_files=exclude_files
        )
        
        print("\n" + "=" * 60)
        print("打包成功!")
        print("=" * 60)
        print(f"压缩包位置: {output_path}")
        print(f"解压后可直接运行: python scripts/start.py")
        print("=" * 60)
        
    except Exception as e:
        print(f"\n打包失败: {e}")
        raise


if __name__ == '__main__':
    main()
