"""
系统停止脚本
"""
import asyncio
import sys
import os
from pathlib import Path

# 添加项目根目录到Python路径
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from core import get_logger
from core.message_bus import Message, MessageType, message_bus


logger = get_logger("shutdown")


async def send_shutdown_to_agents():
    """发送关闭消息给所有Agent"""
    logger.info("正在发送关闭消息给所有Agent...")
    
    # 创建关闭消息
    shutdown_msg = Message(
        sender="system",
        receiver="all",
        msg_type=MessageType.SHUTDOWN,
        payload={'reason': 'user_request'}
    )
    
    # 广播关闭消息
    await message_bus.broadcast(shutdown_msg)
    
    logger.info("关闭消息已广播")


def main():
    """主函数"""
    logger.info("正在停止多Agent系统...")
    
    # 发送关闭消息
    asyncio.run(send_shutdown_to_agents())
    
    # 等待Agent关闭
    import time
    time.sleep(2)
    
    logger.info("系统已停止")


if __name__ == '__main__':
    main()
