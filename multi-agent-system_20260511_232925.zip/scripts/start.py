"""
系统启动脚本
"""
import asyncio
import threading
import time
import sys
import os
from pathlib import Path

# 添加项目根目录到Python路径
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from core import config_manager, logger_manager, get_logger
from core.message_bus import message_bus
from core.task_queue import task_queue
from agents import SchedulerAgent, ContentAgent, MonitorAgent, ReportAgent, NotificationAgent
from services.web_server import app, socketio, start_server


logger = get_logger("startup")


def start_agents():
    """启动所有Agent"""
    logger.info("正在启动Agent...")
    
    # 创建Agent实例
    agents = {
        'scheduler': SchedulerAgent(),
        'content': ContentAgent(),
        'monitor': MonitorAgent(),
        'report': ReportAgent(),
        'notification': NotificationAgent()
    }
    
    # 启动每个Agent
    for name, agent in agents.items():
        try:
            asyncio.run(agent.start())
            logger.info(f"Agent已启动: {name}")
        except Exception as e:
            logger.error(f"Agent启动失败: {name} - {e}")
    
    logger.info("所有Agent已启动")


def start_web_server():
    """启动Web服务器"""
    logger.info("正在启动Web服务器...")
    
    try:
        # 从配置获取参数
        host = config_manager.get('system.web.host', '0.0.0.0')
        port = config_manager.get('system.web.port', 5000)
        debug = config_manager.get('system.web.debug', False)
        
        # 启动服务器
        start_server(host=host, port=port, debug=debug)
    except Exception as e:
        logger.error(f"Web服务器启动失败: {e}")


def main():
    """主函数"""
    logger.info("=" * 60)
    logger.info("多Agent协同运营自动化系统")
    logger.info("=" * 60)
    
    # 加载配置
    try:
        config_manager.load_config()
        logger.info("配置文件已加载")
    except Exception as e:
        logger.error(f"加载配置文件失败: {e}")
        return
    
    # 启动Agent（在新线程中）
    agents_thread = threading.Thread(target=start_agents, daemon=True)
    agents_thread.start()
    logger.info("Agent线程已启动")
    
    # 等待Agent启动完成
    time.sleep(2)
    
    # 启动Web服务器（主线程）
    start_web_server()


if __name__ == '__main__':
    main()
