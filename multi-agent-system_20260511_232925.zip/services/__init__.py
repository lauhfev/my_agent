"""
多Agent协同运营自动化系统 - Web服务
"""

from .web_server import app, socketio
from .api_routes import register_routes
from .websocket_handler import register_websocket_handlers

__all__ = [
    'app',
    'socketio',
    'register_routes',
    'register_websocket_handlers'
]

print("Web服务模块已加载")
