"""
WebSocket处理器 - 实现实时通信
"""
import json
import asyncio
from flask_socketio import SocketIO, emit, join_room, leave_room

# 导入核心模块
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from core import message_bus, task_queue, get_logger


logger = get_logger("websocket")


def register_websocket_handlers(socketio: SocketIO):
    """注册所有WebSocket事件处理器"""
    
    @socketio.on('connect')
    def handle_connect():
        """客户端连接"""
        logger.info("客户端已连接")
        emit('status', {'message': '已连接到多Agent系统'})
    
    @socketio.on('disconnect')
    def handle_disconnect():
        """客户端断开连接"""
        logger.info("客户端已断开连接")
    
    @socketio.on('subscribe')
    def handle_subscribe(data):
        """订阅主题"""
        topic = data.get('topic')
        
        if not topic:
            emit('error', {'message': 'topic不能为空'})
            return
        
        join_room(topic)
        logger.info(f"客户端已订阅主题: {topic}")
        emit('subscribed', {'topic': topic})
        
        # 发送历史消息
        messages = message_bus.get_history(limit=10)
        emit('message_history', {'messages': messages})
    
    @socketio.on('unsubscribe')
    def handle_unsubscribe(data):
        """取消订阅"""
        topic = data.get('topic')
        
        if not topic:
            emit('error', {'message': 'topic不能为空'})
            return
        
        leave_room(topic)
        logger.info(f"客户端已取消订阅主题: {topic}")
        emit('unsubscribed', {'topic': topic})
    
    @socketio.on('send_message')
    def handle_send_message(data):
        """发送消息"""
        topic = data.get('topic')
        message_data = data.get('message')
        
        if not topic or not message_data:
            emit('error', {'message': 'topic和message不能为空'})
            return
        
        # 创建消息
        from core.message_bus import Message, MessageType
        
        message = Message(
            sender='web_client',
            receiver=topic,
            msg_type=MessageType.TASK_REQUEST,
            payload=message_data
        )
        
        # 发布消息
        asyncio.run(message_bus.publish(topic, message))
        
        logger.info(f"消息已发送: {topic}")
        emit('message_sent', {'message_id': message.id})
    
    @socketio.on('get_status')
    def handle_get_status():
        """获取系统状态"""
        try:
            # 获取任务统计
            tasks = task_queue.get_all_tasks()
            task_stats = {
                'total': len(tasks),
                'pending': len([t for t in tasks if t['status'] == 'pending']),
                'running': len([t for t in tasks if t['status'] == 'running']),
                'completed': len([t for t in tasks if t['status'] == 'completed']),
                'failed': len([t for t in tasks if t['status'] == 'failed'])
            }
            
            emit('status_update', {
                'tasks': task_stats,
                'timestamp': '2026-05-11T23:30:00'
            })
        except Exception as e:
            logger.error(f"获取状态失败: {e}")
            emit('error', {'message': str(e)})
    
    @socketio.on('get_agents')
    def handle_get_agents():
        """获取Agent列表"""
        try:
            # 模拟数据
            agents = [
                {'name': 'scheduler', 'status': 'running'},
                {'name': 'content', 'status': 'idle'},
                {'name': 'monitor', 'status': 'running'},
                {'name': 'report', 'status': 'idle'},
                {'name': 'notification', 'status': 'running'}
            ]
            
            emit('agents_update', {'agents': agents})
        except Exception as e:
            logger.error(f"获取Agent列表失败: {e}")
            emit('error', {'message': str(e)})
    
    # 启动消息广播任务
    socketio.start_background_task(target=message_broadcast_task)
    
    logger.info("WebSocket处理器已注册")


def message_broadcast_task():
    """消息广播任务 - 定期推送系统状态"""
    import time
    
    while True:
        socketio = get_socketio()
        if socketio:
            # 广播系统状态更新
            socketio.emit('system_update', {
                'timestamp': time.strftime('%Y-%m-%dT%H:%M:%S'),
                'message': '系统运行正常'
            }, namespace='/')
        
        time.sleep(10)  # 每10秒广播一次


def get_socketio():
    """获取SocketIO实例"""
    try:
        from services.web_server import socketio
        return socketio
    except:
        return None
