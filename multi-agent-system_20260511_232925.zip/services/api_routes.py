"""
API路由定义 - RESTful接口
"""
import json
import asyncio
from flask import request, jsonify, render_template
from pathlib import Path

# 导入核心模块
import sys
from pathlib import Path
sys.path.insert(0, str(Path(__file__).parent.parent))

from core import config_manager, message_bus, task_queue, get_logger
from agents import SchedulerAgent, ContentAgent, MonitorAgent, ReportAgent, NotificationAgent


logger = get_logger("api")


def register_routes(app):
    """注册所有API路由"""
    
    @app.route('/')
    def index():
        """首页 - Dashboard"""
        return render_template('index.html')
    
    @app.route('/api/status')
    def get_status():
        """获取系统状态"""
        try:
            # 获取Agent状态
            agents_status = []
            # 这里应该从实际运行的Agent获取状态
            # 暂时返回模拟数据
            agents_status = [
                {'name': 'scheduler', 'status': 'running', 'last_heartbeat': '2026-05-11T23:30:00'},
                {'name': 'content', 'status': 'idle', 'last_heartbeat': '2026-05-11T23:30:00'},
                {'name': 'monitor', 'status': 'running', 'last_heartbeat': '2026-05-11T23:30:00'},
                {'name': 'report', 'status': 'idle', 'last_heartbeat': '2026-05-11T23:30:00'},
                {'name': 'notification', 'status': 'running', 'last_heartbeat': '2026-05-11T23:30:00'}
            ]
            
            # 获取任务统计
            tasks = task_queue.get_all_tasks()
            task_stats = {
                'total': len(tasks),
                'pending': len([t for t in tasks if t['status'] == 'pending']),
                'running': len([t for t in tasks if t['status'] == 'running']),
                'completed': len([t for t in tasks if t['status'] == 'completed']),
                'failed': len([t for t in tasks if t['status'] == 'failed'])
            }
            
            # 获取消息历史
            messages = message_bus.get_history(limit=10)
            
            return jsonify({
                'success': True,
                'data': {
                    'agents': agents_status,
                    'tasks': task_stats,
                    'recent_messages': messages,
                    'system_time': '2026-05-11T23:30:00'
                }
            })
        except Exception as e:
            logger.error(f"获取系统状态失败: {e}")
            return jsonify({
                'success': False,
                'error': str(e)
            }), 500
    
    @app.route('/api/agents', methods=['GET'])
    def get_agents():
        """获取所有Agent信息"""
        try:
            # 模拟数据
            agents = [
                {
                    'id': '1',
                    'name': 'scheduler',
                    'description': '任务调度器Agent',
                    'status': 'running',
                    'created_at': '2026-05-11T20:00:00',
                    'last_heartbeat': '2026-05-11T23:30:00'
                },
                {
                    'id': '2',
                    'name': 'content',
                    'description': '内容生成Agent',
                    'status': 'idle',
                    'created_at': '2026-05-11T20:00:00',
                    'last_heartbeat': '2026-05-11T23:30:00'
                },
                {
                    'id': '3',
                    'name': 'monitor',
                    'description': '数据监控Agent',
                    'status': 'running',
                    'created_at': '2026-05-11T20:00:00',
                    'last_heartbeat': '2026-05-11T23:30:00'
                },
                {
                    'id': '4',
                    'name': 'report',
                    'description': '报告生成Agent',
                    'status': 'idle',
                    'created_at': '2026-05-11T20:00:00',
                    'last_heartbeat': '2026-05-11T23:30:00'
                },
                {
                    'id': '5',
                    'name': 'notification',
                    'description': '通知推送Agent',
                    'status': 'running',
                    'created_at': '2026-05-11T20:00:00',
                    'last_heartbeat': '2026-05-11T23:30:00'
                }
            ]
            
            return jsonify({
                'success': True,
                'data': agents
            })
        except Exception as e:
            logger.error(f"获取Agent列表失败: {e}")
            return jsonify({
                'success': False,
                'error': str(e)
            }), 500
    
    @app.route('/api/tasks', methods=['GET'])
    def get_tasks():
        """获取所有任务"""
        try:
            tasks = task_queue.get_all_tasks()
            
            return jsonify({
                'success': True,
                'data': tasks
            })
        except Exception as e:
            logger.error(f"获取任务列表失败: {e}")
            return jsonify({
                'success': False,
                'error': str(e)
            }), 500
    
    @app.route('/api/tasks', methods=['POST'])
    def create_task():
        """创建新任务"""
        try:
            data = request.get_json()
            
            # 创建任务
            from core.task_queue import Task, TaskPriority
            
            task = Task(
                priority=data.get('priority', TaskPriority.NORMAL.value),
                created_at='2026-05-11T23:30:00',
                task_id=data.get('task_id', f"task_{len(task_queue.get_all_tasks()) + 1}"),
                task_type=data.get('task_type', 'generic'),
                agent_name=data.get('agent_name', 'scheduler'),
                payload=data.get('payload', {})
            )
            
            # 添加到队列
            task_id = asyncio.run(task_queue.add_task(task))
            
            return jsonify({
                'success': True,
                'data': {
                    'task_id': task_id,
                    'message': '任务已创建'
                }
            })
        except Exception as e:
            logger.error(f"创建任务失败: {e}")
            return jsonify({
                'success': False,
                'error': str(e)
            }), 500
    
    @app.route('/api/config', methods=['GET'])
    def get_config():
        """获取系统配置"""
        try:
            config = config_manager.get('system', {})
            
            return jsonify({
                'success': True,
                'data': config
            })
        except Exception as e:
            logger.error(f"获取配置失败: {e}")
            return jsonify({
                'success': False,
                'error': str(e)
            }), 500
    
    @app.route('/api/logs', methods=['GET'])
    def get_logs():
        """获取系统日志"""
        try:
            log_file = Path('logs/system.log')
            
            if not log_file.exists():
                return jsonify({
                    'success': True,
                    'data': []
                })
            
            # 读取最后100行日志
            with open(log_file, 'r', encoding='utf-8') as f:
                lines = f.readlines()[-100:]
            
            logs = []
            for line in lines:
                logs.append({'message': line.strip()})
            
            return jsonify({
                'success': True,
                'data': logs
            })
        except Exception as e:
            logger.error(f"获取日志失败: {e}")
            return jsonify({
                'success': False,
                'error': str(e)
            }), 500
    
    logger.info("API路由已注册")
