"""
Web服务器 - Flask + SocketIO
"""
import os
import sys
from pathlib import Path

# 添加项目根目录到Python路径
project_root = Path(__file__).parent.parent
sys.path.insert(0, str(project_root))

from flask import Flask
from flask_socketio import SocketIO
from flask_cors import CORS

# 创建Flask应用
app = Flask(__name__)
app.config['SECRET_KEY'] = 'multi-agent-system-secret-key'

# 启用CORS
CORS(app)

# 创建SocketIO
socketio = SocketIO(
    app,
    cors_allowed_origins="*",
    async_mode='threading'
)

# 注册路由和WebSocket处理器
from .api_routes import register_routes
from .websocket_handler import register_websocket_handlers

register_routes(app)
register_websocket_handlers(socketio)

def start_server(host='0.0.0.0', port=5000, debug=False):
    """启动Web服务器"""
    socketio.run(
        app,
        host=host,
        port=port,
        debug=debug,
        allow_unsafe_werkzeug=True
    )

if __name__ == '__main__':
    start_server()
