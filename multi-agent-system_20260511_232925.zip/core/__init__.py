"""
多Agent协同运营自动化系统 - 核心框架
"""

from .config_manager import ConfigManager, config_manager
from .logger import LoggerManager, logger_manager, get_logger
from .message_bus import MessageBus, Message, MessageType, message_bus
from .task_queue import TaskQueue, Task, TaskStatus, TaskPriority, task_queue

__all__ = [
    'ConfigManager',
    'config_manager',
    'LoggerManager',
    'logger_manager',
    'get_logger',
    'MessageBus',
    'Message',
    'MessageType',
    'message_bus',
    'TaskQueue',
    'Task',
    'TaskStatus',
    'TaskPriority',
    'task_queue'
]

print("核心框架已加载")
