"""
日志管理器 - 统一日志格式和输出
"""
import logging
import os
from logging.handlers import RotatingFileHandler
from pathlib import Path
from typing import Optional
from .config_manager import config_manager


class LoggerManager:
    """日志管理器单例类"""
    
    _instance = None
    _loggers = {}
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(LoggerManager, cls).__new__(cls)
        return cls._instance
    
    def get_logger(self, name: str = "system") -> logging.Logger:
        """获取指定名称的日志器"""
        if name in self._loggers:
            return self._loggers[name]
        
        # 创建新的日志器
        logger = logging.getLogger(name)
        logger.setLevel(logging.DEBUG)
        
        # 避免重复添加handler
        if not logger.handlers:
            # 控制台handler
            console_handler = logging.StreamHandler()
            console_handler.setLevel(logging.INFO)
            
            # 文件handler
            log_dir = Path("logs")
            log_dir.mkdir(exist_ok=True)
            
            file_handler = RotatingFileHandler(
                log_dir / f"{name}.log",
                maxBytes=10*1024*1024,  # 10MB
                backupCount=5,
                encoding='utf-8'
            )
            file_handler.setLevel(logging.DEBUG)
            
            # 格式化
            formatter = logging.Formatter(
                '%(asctime)s - %(name)s - %(levelname)s - %(message)s',
                datefmt='%Y-%m-%d %H:%M:%S'
            )
            console_handler.setFormatter(formatter)
            file_handler.setFormatter(formatter)
            
            logger.addHandler(console_handler)
            logger.addHandler(file_handler)
        
        self._loggers[name] = logger
        return logger
    
    def set_level(self, level: str):
        """设置所有日志器的级别"""
        level_map = {
            'DEBUG': logging.DEBUG,
            'INFO': logging.INFO,
            'WARNING': logging.WARNING,
            'ERROR': logging.ERROR,
            'CRITICAL': logging.CRITICAL
        }
        
        if level in level_map:
            for logger in self._loggers.values():
                logger.setLevel(level_map[level])


# 全局日志管理器实例
logger_manager = LoggerManager()


def get_logger(name: str = "system") -> logging.Logger:
    """获取日志器的快捷函数"""
    return logger_manager.get_logger(name)
