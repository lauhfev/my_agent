"""
配置管理器 - 负责加载和管理YAML配置文件
"""
import yaml
import json
from pathlib import Path
from typing import Any, Dict, Optional


class ConfigManager:
    """配置管理器单例类"""
    
    _instance = None
    _config = {}
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(ConfigManager, cls).__new__(cls)
        return cls._instance
    
    def load_config(self, config_path: str = "config/system.yaml") -> Dict[str, Any]:
        """加载配置文件"""
        config_file = Path(config_path)
        
        if not config_file.exists():
            raise FileNotFoundError(f"配置文件不存在: {config_path}")
        
        with open(config_file, 'r', encoding='utf-8') as f:
            self._config = yaml.safe_load(f)
        
        # 加载其他配置文件
        self._load_additional_configs()
        
        return self._config
    
    def _load_additional_configs(self):
        """加载额外的配置文件"""
        config_dir = Path("config")
        
        # 加载agents.yaml
        agents_config_file = config_dir / "agents.yaml"
        if agents_config_file.exists():
            with open(agents_config_file, 'r', encoding='utf-8') as f:
                self._config['agents'] = yaml.safe_load(f)
        
        # 加载tasks.yaml
        tasks_config_file = config_dir / "tasks.yaml"
        if tasks_config_file.exists():
            with open(tasks_config_file, 'r', encoding='utf-8') as f:
                self._config['tasks'] = yaml.safe_load(f)
    
    def get(self, key: str, default: Optional[Any] = None) -> Any:
        """获取配置值，支持点号路径"""
        keys = key.split('.')
        value = self._config
        
        for k in keys:
            if isinstance(value, dict) and k in value:
                value = value[k]
            else:
                return default
        
        return value
    
    def set(self, key: str, value: Any):
        """设置配置值"""
        keys = key.split('.')
        config = self._config
        
        for k in keys[:-1]:
            if k not in config:
                config[k] = {}
            config = config[k]
        
        config[keys[-1]] = value
    
    def get_agent_config(self, agent_name: str) -> Dict[str, Any]:
        """获取指定Agent的配置"""
        agents_config = self._config.get('agents', {})
        return agents_config.get(agent_name, {})
    
    def reload(self):
        """重新加载配置"""
        self._config.clear()
        self.load_config()
    
    def to_json(self) -> str:
        """将配置转换为JSON字符串"""
        return json.dumps(self._config, ensure_ascii=False, indent=2)


# 全局配置管理器实例
config_manager = ConfigManager()
