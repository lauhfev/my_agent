"""
任务队列 - 管理任务优先级和执行（简化版）
"""
import heapq
from typing import Dict, List, Optional, Callable
from enum import Enum
from dataclasses import dataclass, field
from core.logger import get_logger
from core.message_bus import Message, MessageType


class TaskStatus(Enum):
    """任务状态枚举"""
    PENDING = "pending"
    RUNNING = "running"
    COMPLETED = "completed"
    FAILED = "failed"
    CANCELLED = "cancelled"


class TaskPriority(Enum):
    """任务优先级枚举"""
    HIGH = 1
    NORMAL = 2
    LOW = 3


@dataclass(order=True)
class Task:
    """任务类"""
    
    priority: int = field(compare=True)
    created_at: str = field(compare=False)
    task_id: str = field(compare=False)
    task_type: str = field(compare=False)
    agent_name: str = field(compare=False)
    payload: Dict = field(compare=False, default_factory=dict)
    status: TaskStatus = field(compare=False, default=TaskStatus.PENDING)
    result: Optional[Dict] = field(compare=False, default=None)
    error: Optional[str] = field(compare=False, default=None)
    retry_count: int = field(compare=False, default=0)
    max_retries: int = field(compare=False, default=3)
    
    def to_dict(self) -> Dict:
        """转换为字典"""
        return {
            'task_id': self.task_id,
            'task_type': self.task_type,
            'agent_name': self.agent_name,
            'priority': self.priority,
            'status': self.status.value,
            'payload': self.payload,
            'result': self.result,
            'error': self.error,
            'retry_count': self.retry_count,
            'max_retries': self.max_retries,
            'created_at': self.created_at
        }


class TaskQueue:
    """任务队列单例类（简化版）"""
    
    _instance = None
    _queue: List[Task] = []
    _tasks: Dict[str, Task] = {}
    _handlers: Dict[str, Callable] = {}
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(TaskQueue, cls).__new__(cls)
            cls._queue = []
            cls._tasks = {}
            cls._handlers = {}
        return cls._instance
    
    def __init__(self):
        self.logger = get_logger("task_queue")
    
    def add_task(self, task: Task) -> str:
        """添加任务到队列"""
        heapq.heappush(self._queue, task)
        self._tasks[task.task_id] = task
        self.logger.info(f"任务已添加: {task.task_id} (优先级: {task.priority})")
        return task.task_id
    
    def get_task(self) -> Optional[Task]:
        """获取下一个待执行任务"""
        if not self._queue:
            return None
        
        task = heapq.heappop(self._queue)
        task.status = TaskStatus.RUNNING
        self.logger.debug(f"任务已取出: {task.task_id}")
        return task
    
    def complete_task(self, task_id: str, result: Dict = None):
        """标记任务完成"""
        if task_id in self._tasks:
            task = self._tasks[task_id]
            task.status = TaskStatus.COMPLETED
            task.result = result
            self.logger.info(f"任务已完成: {task_id}")
    
    def fail_task(self, task_id: str, error: str):
        """标记任务失败"""
        if task_id in self._tasks:
            task = self._tasks[task_id]
            task.retry_count += 1
            
            if task.retry_count >= task.max_retries:
                task.status = TaskStatus.FAILED
                task.error = error
                self.logger.error(f"任务失败(已达最大重试次数): {task_id} - {error}")
            else:
                # 重新入队
                task.status = TaskStatus.PENDING
                heapq.heappush(self._queue, task)
                self.logger.warning(f"任务失败(将重试): {task_id} - {error} (重试 {task.retry_count}/{task.max_retries})")
    
    def cancel_task(self, task_id: str):
        """取消任务"""
        if task_id in self._tasks:
            task = self._tasks[task_id]
            if task.status in [TaskStatus.PENDING, TaskStatus.RUNNING]:
                task.status = TaskStatus.CANCELLED
                self.logger.info(f"任务已取消: {task_id}")
    
    def get_task_status(self, task_id: str) -> Optional[TaskStatus]:
        """获取任务状态"""
        if task_id in self._tasks:
            return self._tasks[task_id].status
        return None
    
    def get_all_tasks(self) -> List[Dict]:
        """获取所有任务"""
        return [task.to_dict() for task in self._tasks.values()]
    
    def register_handler(self, task_type: str, handler: Callable):
        """注册任务处理器"""
        self._handlers[task_type] = handler
        self.logger.debug(f"任务处理器已注册: {task_type}")
    
    def clear_completed_tasks(self):
        """清理已完成任务"""
        self._tasks = {
            k: v for k, v in self._tasks.items() 
            if v.status not in [TaskStatus.COMPLETED, TaskStatus.FAILED, TaskStatus.CANCELLED]
        }
        self.logger.info("已完成任务已清理")


# 全局任务队列实例
task_queue = TaskQueue()
