"""
消息总线 - 实现Agent间通信
"""
import asyncio
import json
from typing import Callable, Dict, List, Any
from enum import Enum
from datetime import datetime
from .logger import get_logger


class MessageType(Enum):
    """消息类型枚举"""
    TASK_REQUEST = "task_request"
    TASK_RESPONSE = "task_response"
    STATUS_UPDATE = "status_update"
    NOTIFICATION = "notification"
    HEARTBEAT = "heartbeat"
    SHUTDOWN = "shutdown"


class Message:
    """消息类"""
    
    def __init__(self, sender: str, receiver: str, msg_type: MessageType, 
                 payload: Any = None, metadata: Dict = None):
        self.sender = sender
        self.receiver = receiver
        self.type = msg_type
        self.payload = payload
        self.metadata = metadata or {}
        self.timestamp = datetime.now().isoformat()
        self.id = f"{sender}_{receiver}_{self.timestamp}"
    
    def to_dict(self) -> Dict:
        """转换为字典"""
        return {
            'id': self.id,
            'sender': self.sender,
            'receiver': self.receiver,
            'type': self.type.value,
            'payload': self.payload,
            'metadata': self.metadata,
            'timestamp': self.timestamp
        }
    
    def to_json(self) -> str:
        """转换为JSON字符串"""
        return json.dumps(self.to_dict(), ensure_ascii=False)
    
    @classmethod
    def from_dict(cls, data: Dict) -> 'Message':
        """从字典创建消息"""
        msg = cls(
            sender=data['sender'],
            receiver=data['receiver'],
            msg_type=MessageType(data['type']),
            payload=data['payload'],
            metadata=data.get('metadata', {})
        )
        msg.timestamp = data['timestamp']
        msg.id = data['id']
        return msg


class MessageBus:
    """消息总线单例类"""
    
    _instance = None
    _subscribers: Dict[str, List[Callable]] = {}
    _message_history: List[Message] = []
    _max_history = 1000
    
    def __new__(cls):
        if cls._instance is None:
            cls._instance = super(MessageBus, cls).__new__(cls)
            cls._subscribers = {}
            cls._message_history = []
        return cls._instance
    
    def __init__(self):
        self.logger = get_logger("message_bus")
    
    async def publish(self, topic: str, message: Message) -> None:
        """发布消息到指定主题"""
        self.logger.debug(f"发布消息: {topic} <- {message.sender}")
        
        # 添加到历史记录
        self._message_history.append(message)
        if len(self._message_history) > self._max_history:
            self._message_history.pop(0)
        
        # 通知订阅者
        if topic in self._subscribers:
            for handler in self._subscribers[topic]:
                try:
                    await handler(message)
                except Exception as e:
                    self.logger.error(f"消息处理失败: {e}")
    
    def subscribe(self, topic: str, handler: Callable) -> None:
        """订阅指定主题的消息"""
        if topic not in self._subscribers:
            self._subscribers[topic] = []
        self._subscribers[topic].append(handler)
        self.logger.debug(f"新增订阅: {topic}")
    
    def unsubscribe(self, topic: str, handler: Callable) -> None:
        """取消订阅"""
        if topic in self._subscribers:
            if handler in self._subscribers[topic]:
                self._subscribers[topic].remove(handler)
                self.logger.debug(f"取消订阅: {topic}")
    
    async def send_to_agent(self, message: Message) -> None:
        """发送消息给指定Agent"""
        topic = f"agent.{message.receiver}"
        await self.publish(topic, message)
    
    async def broadcast(self, message: Message) -> None:
        """广播消息给所有Agent"""
        topic = "agent.all"
        await self.publish(topic, message)
    
    def get_history(self, agent_name: str = None, limit: int = 100) -> List[Dict]:
        """获取消息历史"""
        history = self._message_history
        
        if agent_name:
            history = [m for m in history if m.sender == agent_name or m.receiver == agent_name]
        
        return [m.to_dict() for m in history[-limit:]]
    
    def clear_history(self):
        """清空消息历史"""
        self._message_history.clear()
        self.logger.info("消息历史已清空")


# 全局消息总线实例
message_bus = MessageBus()
