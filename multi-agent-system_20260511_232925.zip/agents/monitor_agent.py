"""
数据监控Agent - 监控系统指标和数据变化
"""
import asyncio
import random
from typing import Dict, Any
from datetime import datetime
from collections import deque

from .base_agent import BaseAgent, AgentStatus
from . import Task, task_queue, message_bus, Message, MessageType
from . import get_logger


class MonitorAgent(BaseAgent):
    """数据监控Agent"""
    
    def __init__(self):
        super().__init__(
            name="monitor",
            description="数据监控Agent，监控系统指标和数据变化"
        )
        self.monitors = {}
        self.metrics_history = {}
        self.alert_thresholds = {
            'cpu_usage': 80.0,
            'memory_usage': 85.0,
            'disk_usage': 90.0,
            'response_time': 2.0,
            'error_rate': 5.0
        }
        self.is_monitoring = False
    
    async def initialize(self) -> None:
        """初始化数据监控Agent"""
        self.logger.info("数据监控Agent正在初始化...")
        
        # 注册任务处理器
        task_queue.register_handler("monitor_metric", self._handle_monitor_metric)
        task_queue.register_handler("get_metrics", self._handle_get_metrics)
        task_queue.register_handler("set_threshold", self._handle_set_threshold)
        
        # 加载监控配置
        await self._load_monitor_config()
        
        self.logger.info("数据监控Agent初始化完成")
    
    async def execute(self, task: Task) -> Dict:
        """执行数据监控任务"""
        self.logger.info(f"执行数据监控任务: {task.task_id}")
        
        result = {}
        task_type = task.task_type
        
        if task_type == "monitor_metric":
            result = await self._monitor_metric(task.payload)
        elif task_type == "get_metrics":
            result = await self._get_metrics(task.payload)
        elif task_type == "set_threshold":
            result = await self._set_threshold(task.payload)
        elif task_type == "start_monitoring":
            result = await self._start_monitoring(task.payload)
        elif task_type == "stop_monitoring":
            result = await self._stop_monitoring()
        else:
            raise ValueError(f"未知的监控任务类型: {task_type}")
        
        return result
    
    async def shutdown(self) -> None:
        """关闭数据监控Agent"""
        self.logger.info("数据监控Agent正在关闭...")
        
        # 停止所有监控任务
        self.is_monitoring = False
        
        self.logger.info("数据监控Agent已关闭")
    
    async def _handle_monitor_metric(self, task: Task) -> Dict:
        """处理监控指标请求"""
        return await self._monitor_metric(task.payload)
    
    async def _handle_get_metrics(self, task: Task) -> Dict:
        """处理获取指标请求"""
        return await self._get_metrics(task.payload)
    
    async def _handle_set_threshold(self, task: Task) -> Dict:
        """处理设置阈值请求"""
        return await self._set_threshold(task.payload)
    
    async def _monitor_metric(self, payload: Dict) -> Dict:
        """监控单个指标"""
        metric_name = payload.get('metric_name')
        
        if not metric_name:
            raise ValueError("metric_name不能为空")
        
        # 模拟获取指标值
        if metric_name == 'cpu_usage':
            value = random.uniform(20.0, 90.0)
        elif metric_name == 'memory_usage':
            value = random.uniform(30.0, 85.0)
        elif metric_name == 'disk_usage':
            value = random.uniform(40.0, 80.0)
        elif metric_name == 'response_time':
            value = random.uniform(0.1, 3.0)
        elif metric_name == 'error_rate':
            value = random.uniform(0.0, 10.0)
        else:
            value = random.uniform(0.0, 100.0)
        
        # 保存到历史记录
        if metric_name not in self.metrics_history:
            self.metrics_history[metric_name] = deque(maxlen=100)
        
        timestamp = datetime.now().isoformat()
        self.metrics_history[metric_name].append({
            'timestamp': timestamp,
            'value': value
        })
        
        # 检查阈值
        alert = False
        if metric_name in self.alert_thresholds:
            threshold = self.alert_thresholds[metric_name]
            if value > threshold:
                alert = True
                await self._send_alert(metric_name, value, threshold)
        
        result = {
            'metric_name': metric_name,
            'value': round(value, 2),
            'timestamp': timestamp,
            'alert': alert,
            'threshold': self.alert_thresholds.get(metric_name)
        }
        
        self.logger.info(f"指标监控完成: {metric_name} = {value:.2f}")
        
        return result
    
    async def _get_metrics(self, payload: Dict) -> Dict:
        """获取指标历史数据"""
        metric_name = payload.get('metric_name')
        limit = payload.get('limit', 10)
        
        if metric_name:
            history = list(self.metrics_history.get(metric_name, []))[-limit:]
            return {
                'metric_name': metric_name,
                'history': history,
                'count': len(history)
            }
        else:
            # 返回所有指标的最新值
            latest = {}
            for name, history in self.metrics_history.items():
                if history:
                    latest[name] = history[-1]
            
            return {
                'metrics': latest,
                'count': len(latest)
            }
    
    async def _set_threshold(self, payload: Dict) -> Dict:
        """设置指标阈值"""
        metric_name = payload.get('metric_name')
        threshold = payload.get('threshold')
        
        if not metric_name or threshold is None:
            raise ValueError("metric_name和threshold不能为空")
        
        self.alert_thresholds[metric_name] = float(threshold)
        
        result = {
            'metric_name': metric_name,
            'threshold': threshold,
            'updated_at': datetime.now().isoformat()
        }
        
        self.logger.info(f"阈值已设置: {metric_name} = {threshold}")
        
        return result
    
    async def _start_monitoring(self, payload: Dict) -> Dict:
        """开始持续监控"""
        interval = payload.get('interval', 5)  # 默认5秒
        
        if self.is_monitoring:
            return {'status': 'already_running'}
        
        self.is_monitoring = True
        
        # 启动监控循环
        asyncio.create_task(self._monitoring_loop(interval))
        
        return {
            'status': 'started',
            'interval': interval
        }
    
    async def _stop_monitoring(self) -> Dict:
        """停止持续监控"""
        self.is_monitoring = False
        
        return {'status': 'stopped'}
    
    async def _monitoring_loop(self, interval: int):
        """监控循环"""
        self.logger.info(f"开始持续监控 (间隔: {interval}秒)")
        
        while self.is_monitoring:
            try:
                # 监控所有注册的指标
                for metric_name in self.alert_thresholds.keys():
                    await self._monitor_metric({'metric_name': metric_name})
                
                await asyncio.sleep(interval)
            except asyncio.CancelledError:
                break
            except Exception as e:
                self.logger.error(f"监控循环出错: {e}")
                await asyncio.sleep(interval)
        
        self.logger.info("持续监控已停止")
    
    async def _send_alert(self, metric_name: str, value: float, threshold: float):
        """发送告警"""
        alert_msg = Message(
            sender=self.name,
            receiver="notification",
            msg_type=MessageType.NOTIFICATION,
            payload={
                'type': 'alert',
                'metric_name': metric_name,
                'value': value,
                'threshold': threshold,
                'message': f"告警: {metric_name} 超过阈值！当前值: {value:.2f}, 阈值: {threshold}"
            }
        )
        await message_bus.send_to_agent(alert_msg)
        
        self.logger.warning(f"告警已发送: {metric_name} = {value:.2f} > {threshold}")
    
    async def _load_monitor_config(self):
        """加载监控配置"""
        try:
            from core.config_manager import config_manager
            
            monitor_config = config_manager.get('agents.monitor', {})
            
            # 更新阈值配置
            thresholds = monitor_config.get('thresholds', {})
            for key, value in thresholds.items():
                if key in self.alert_thresholds:
                    self.alert_thresholds[key] = value
            
            self.logger.info("监控配置已加载")
        except Exception as e:
            self.logger.warning(f"加载监控配置失败: {e}")
