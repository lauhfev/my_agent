"""
报告生成Agent - 生成运营报告
"""
import asyncio
import json
from typing import Dict, Any, List
from datetime import datetime, timedelta
from pathlib import Path

from .base_agent import BaseAgent, AgentStatus
from . import Task, task_queue, message_bus, Message, MessageType
from . import get_logger


class ReportAgent(BaseAgent):
    """报告生成Agent"""
    
    def __init__(self):
        super().__init__(
            name="report",
            description="报告生成Agent，生成运营报告"
        )
        self.report_types = ['daily', 'weekly', 'monthly', 'custom']
        self.reports_dir = Path("data/reports")
        self.report_templates = {
            'daily': """
# 每日运营报告

**日期**: {date}
**生成时间**: {generated_at}

## 关键指标
- 新增用户: {new_users}
- 活跃用户: {active_users}
- 内容发布数: {content_published}
- 监控告警数: {alerts_count}

## 任务执行情况
- 总任务数: {total_tasks}
- 成功任务: {success_tasks}
- 失败任务: {failed_tasks}
- 成功率: {success_rate}%

## 总结
{summary}

---
*本报告由ReportAgent自动生成*
            """,
            'weekly': """
# 每周运营报告

**周期**: {start_date} 至 {end_date}
**生成时间**: {generated_at}

## 本周概览
- 新增用户: {new_users}
- 活跃用户: {active_users}
- 内容发布数: {content_published}
- 监控告警数: {alerts_count}

## 任务执行情况
- 总任务数: {total_tasks}
- 成功任务: {success_tasks}
- 失败任务: {failed_tasks}
- 成功率: {success_rate}%

## 详细分析
{analysis}

## 下周计划
{next_week_plan}

---
*本报告由ReportAgent自动生成*
            """
        }
    
    async def initialize(self) -> None:
        """初始化报告生成Agent"""
        self.logger.info("报告生成Agent正在初始化...")
        
        # 创建报告目录
        self.reports_dir.mkdir(parents=True, exist_ok=True)
        
        # 注册任务处理器
        task_queue.register_handler("generate_report", self._handle_generate_report)
        task_queue.register_handler("list_reports", self._handle_list_reports)
        
        self.logger.info("报告生成Agent初始化完成")
    
    async def execute(self, task: Task) -> Dict:
        """执行报告生成任务"""
        self.logger.info(f"执行报告生成任务: {task.task_id}")
        
        result = {}
        task_type = task.task_type
        
        if task_type == "generate_report":
            result = await self._generate_report(task.payload)
        elif task_type == "list_reports":
            result = await self._list_reports(task.payload)
        elif task_type == "get_report":
            result = await self._get_report(task.payload)
        else:
            # 直接生成报告
            result = await self._generate_report(task.payload)
        
        return result
    
    async def shutdown(self) -> None:
        """关闭报告生成Agent"""
        self.logger.info("报告生成Agent正在关闭...")
        self.logger.info("报告生成Agent已关闭")
    
    async def _handle_generate_report(self, task: Task) -> Dict:
        """处理生成报告请求"""
        return await self._generate_report(task.payload)
    
    async def _handle_list_reports(self, task: Task) -> Dict:
        """处理列出报告请求"""
        return await self._list_reports(task.payload)
    
    async def _generate_report(self, payload: Dict) -> Dict:
        """生成报告"""
        report_type = payload.get('report_type', 'daily')
        start_date = payload.get('start_date')
        end_date = payload.get('end_date')
        
        if report_type not in self.report_types:
            raise ValueError(f"不支持的报告类型: {report_type}")
        
        # 模拟数据生成延迟
        await asyncio.sleep(2)
        
        # 生成报告数据
        report_data = await self._collect_report_data(report_type, start_date, end_date)
        
        # 使用模板生成报告
        template = self.report_templates.get(report_type, self.report_templates['daily'])
        report_content = template.format(**report_data)
        
        # 保存报告
        report_id = f"{report_type}_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        report_file = self.reports_dir / f"{report_id}.md"
        
        with open(report_file, 'w', encoding='utf-8') as f:
            f.write(report_content)
        
        result = {
            'report_id': report_id,
            'report_type': report_type,
            'file_path': str(report_file),
            'generated_at': datetime.now().isoformat(),
            'data': report_data
        }
        
        self.logger.info(f"报告已生成: {report_id} -> {report_file}")
        
        # 发送通知
        await self.send_notification(
            content=f"报告已生成: {report_id}",
            metadata={'report_id': report_id, 'file_path': str(report_file)}
        )
        
        return result
    
    async def _collect_report_data(self, report_type: str, start_date: str, end_date: str) -> Dict:
        """收集报告数据"""
        # 模拟数据收集
        import random
        
        now = datetime.now()
        
        if report_type == 'daily':
            date = now.strftime('%Y-%m-%d')
            return {
                'date': date,
                'generated_at': now.isoformat(),
                'new_users': random.randint(50, 200),
                'active_users': random.randint(500, 2000),
                'content_published': random.randint(5, 20),
                'alerts_count': random.randint(0, 10),
                'total_tasks': random.randint(50, 100),
                'success_tasks': random.randint(40, 95),
                'failed_tasks': random.randint(0, 10),
                'success_rate': random.randint(85, 99),
                'summary': '今日运营情况良好，所有系统运行正常。'
            }
        elif report_type == 'weekly':
            start = (now - timedelta(days=7)).strftime('%Y-%m-%d')
            end = now.strftime('%Y-%m-%d')
            return {
                'start_date': start,
                'end_date': end,
                'generated_at': now.isoformat(),
                'new_users': random.randint(300, 1000),
                'active_users': random.randint(3000, 8000),
                'content_published': random.randint(30, 100),
                'alerts_count': random.randint(5, 30),
                'total_tasks': random.randint(300, 600),
                'success_tasks': random.randint(250, 580),
                'failed_tasks': random.randint(5, 50),
                'success_rate': random.randint(88, 98),
                'analysis': '本周运营数据整体向好，用户增长率达到15%。',
                'next_week_plan': '下周计划重点提升内容质量和用户互动率。'
            }
        else:
            return {
                'generated_at': now.isoformat(),
                'report_type': report_type,
                'summary': '自定义报告生成完成。'
            }
    
    async def _list_reports(self, payload: Dict) -> Dict:
        """列出所有报告"""
        reports = []
        
        for report_file in self.reports_dir.glob("*.md"):
            reports.append({
                'filename': report_file.name,
                'path': str(report_file),
                'size': report_file.stat().st_size,
                'created_at': datetime.fromtimestamp(report_file.stat().st_ctime).isoformat()
            })
        
        return {
            'reports': reports,
            'count': len(reports)
        }
    
    async def _get_report(self, payload: Dict) -> Dict:
        """获取指定报告"""
        report_id = payload.get('report_id')
        
        if not report_id:
            raise ValueError("report_id不能为空")
        
        report_file = self.reports_dir / f"{report_id}.md"
        
        if not report_file.exists():
            raise FileNotFoundError(f"报告不存在: {report_id}")
        
        with open(report_file, 'r', encoding='utf-8') as f:
            content = f.read()
        
        return {
            'report_id': report_id,
            'content': content,
            'file_path': str(report_file)
        }
