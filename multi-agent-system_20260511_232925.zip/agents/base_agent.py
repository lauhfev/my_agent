"""
Agent基类 - 定义Agent生命周期和通信接口
"""
import asyncio
import uuid
from abc import ABC, abstractmethod
from typing import Dict, Any, Optional, Callable
from enum import Enum
from datetime import datetime
from . import get_logger
from . import Message, MessageType, message_bus
from . import Task, TaskStatus, task_queue


class AgentStatus(Enum):
    """Agent状态枚举"""
    IDLE = "idle"
    RUNNING = "running"
    PAUSED = "paused"
    STOPPED = "stopped"
    ERROR = "error"


class BaseAgent(ABC):
    """Agent基类"""
    
    def __init__(self, name: str, description: str = ""):
        self.name = name
        self.description = description
        self.id = str(uuid.uuid4())
        self.status = AgentStatus.IDLE
        self.logger = get_logger(f"agent.{name}")
        self.created_at = datetime.now().isoformat()
        self.last_heartbeat = datetime.now().isoformat()
        self.message_handlers: Dict[str, Callable] = {}
        self.is_running = False
        
        # 注册消息处理器
        self._register_message_handlers()
        
        self.logger.info(f"Agent已初始化: {name} ({description})")
    
    def _register_message_handlers(self):
        """注册消息处理器 - 子类可重写"""
        self.register_handler(MessageType.TASK_REQUEST, self._handle_task_request)
        self.register_handler(MessageType.STATUS_UPDATE, self._handle_status_update)
        self.register_handler(MessageType.SHUTDOWN, self._handle_shutdown)
    
    def register_handler(self, msg_type: MessageType, handler: Callable):
        """注册消息处理器"""
        self.message_handlers[msg_type.value] = handler
        self.logger.debug(f"消息处理器已注册: {msg_type.value}")
    
    async def _handle_task_request(self, message: Message):
        """处理任务请求 - 默认实现"""
        task_data = message.payload
        task = Task.from_dict(task_data)
        
        try:
            result = await self.execute(task)
            await self.send_response(message.sender, task, result)
        except Exception as e:
            self.logger.error(f"任务执行失败: {e}")
            await self.send_error(message.sender, task, str(e))
    
    async def _handle_status_update(self, message: Message):
        """处理状态更新消息 - 可重写"""
        self.logger.debug(f"收到状态更新: {message.payload}")
    
    async def _handle_shutdown(self, message: Message):
        """处理关闭消息"""
        self.logger.info(f"收到关闭指令")
        await self.shutdown()
    
    async def send_response(self, receiver: str, task: Task, result: Dict):
        """发送任务响应"""
        response_msg = Message(
            sender=self.name,
            receiver=receiver,
            msg_type=MessageType.TASK_RESPONSE,
            payload={
                'task_id': task.task_id,
                'result': result,
                'status': 'success'
            }
        )
        await message_bus.send_to_agent(response_msg)
    
    async def send_error(self, receiver: str, task: Task, error: str):
        """发送错误响应"""
        error_msg = Message(
            sender=self.name,
            receiver=receiver,
            msg_type=MessageType.TASK_RESPONSE,
            payload={
                'task_id': task.task_id,
                'error': error,
                'status': 'error'
            }
        )
        await message_bus.send_to_agent(error_msg)
    
    async def send_notification(self, content: str, metadata: Dict = None):
        """发送通知"""
        notification = Message(
            sender=self.name,
            receiver="all",
            msg_type=MessageType.NOTIFICATION,
            payload={'content': content},
            metadata=metadata
        )
        await message_bus.broadcast(notification)
    
    async def update_status(self):
        """更新心跳时间"""
        self.last_heartbeat = datetime.now().isoformat()
        
        # 发送状态更新
        status_msg = Message(
            sender=self.name,
            receiver="scheduler",
            msg_type=MessageType.STATUS_UPDATE,
            payload={
                'status': self.status.value,
                'last_heartbeat': self.last_heartbeat
            }
        )
        await message_bus.send_to_agent(status_msg)
    
    @abstractmethod
    async def initialize(self) -> None:
        """初始化Agent - 子类必须实现"""
        pass
    
    @abstractmethod
    async def execute(self, task: Task) -> Dict:
        """执行任务 - 子类必须实现"""
        pass
    
    @abstractmethod
    async def shutdown(self) -> None:
        """关闭Agent - 子类必须实现"""
        pass
    
    async def start(self):
        """启动Agent"""
        self.logger.info(f"Agent正在启动: {self.name}")
        self.status = AgentStatus.RUNNING
        self.is_running = True
        
        try:
            await self.initialize()
            await self.update_status()
            
            # 启动消息监听
            await self._start_message_listener()
        except Exception as e:
            self.status = AgentStatus.ERROR
            self.logger.error(f"Agent启动失败: {e}")
            raise
    
    async def stop(self):
        """停止Agent"""
        self.logger.info(f"Agent正在停止: {self.name}")
        self.is_running = False
        self.status = AgentStatus.STOPPED
        await self.shutdown()
    
    async def _start_message_listener(self):
        """启动消息监听器"""
        topic = f"agent.{self.name}"
        
        async def message_handler(message: Message):
            """消息处理包装器"""
            if message.type.value in self.message_handlers:
                try:
                    await self.message_handlers[message.type.value](message)
                except Exception as e:
                    self.logger.error(f"消息处理失败: {e}")
        
        message_bus.subscribe(topic, message_handler)
        self.logger.debug(f"消息监听器已启动: {topic}")
        
        # 保持运行
        while self.is_running:
            await asyncio.sleep(1)
    
    def get_info(self) -> Dict:
        """获取Agent信息"""
        return {
            'id': self.id,
            'name': self.name,
            'description': self.description,
            'status': self.status.value,
            'created_at': self.created_at,
            'last_heartbeat': self.last_heartbeat
        }
