"""
通知推送Agent - 发送通知消息
"""
import asyncio
import json
from typing import Dict, Any, List
from datetime import datetime
from pathlib import Path

from .base_agent import BaseAgent, AgentStatus
from . import Task, task_queue, message_bus, Message, MessageType
from . import get_logger


class NotificationAgent(BaseAgent):
    """通知推送Agent"""
    
    def __init__(self):
        super().__init__(
            name="notification",
            description="通知推送Agent，发送通知消息"
        )
        self.notification_types = ['email', 'sms', 'webhook', 'console']
        self.notifications_dir = Path("data/notifications")
        self.notification_history: List[Dict] = []
        self.max_history = 1000
    
    async def initialize(self) -> None:
        """初始化通知推送Agent"""
        self.logger.info("通知推送Agent正在初始化...")
        
        # 创建通知目录
        self.notifications_dir.mkdir(parents=True, exist_ok=True)
        
        # 注册任务处理器
        task_queue.register_handler("send_notification", self._handle_send_notification)
        task_queue.register_handler("list_notifications", self._handle_list_notifications)
        
        # 订阅通知消息
        message_bus.subscribe("agent.all", self._handle_notification_message)
        
        self.logger.info("通知推送Agent初始化完成")
    
    async def execute(self, task: Task) -> Dict:
        """执行通知推送任务"""
        self.logger.info(f"执行通知推送任务: {task.task_id}")
        
        result = {}
        task_type = task.task_type
        
        if task_type == "send_notification":
            result = await self._send_notification(task.payload)
        elif task_type == "list_notifications":
            result = await self._list_notifications(task.payload)
        elif task_type == "broadcast_notification":
            result = await self._broadcast_notification(task.payload)
        else:
            raise ValueError(f"未知的通知任务类型: {task_type}")
        
        return result
    
    async def shutdown(self) -> None:
        """关闭通知推送Agent"""
        self.logger.info("通知推送Agent正在关闭...")
        
        # 保存通知历史
        await self._save_notification_history()
        
        self.logger.info("通知推送Agent已关闭")
    
    async def _handle_send_notification(self, task: Task) -> Dict:
        """处理发送通知请求"""
        return await self._send_notification(task.payload)
    
    async def _handle_list_notifications(self, task: Task) -> Dict:
        """处理列出通知请求"""
        return await self._list_notifications(task.payload)
    
    async def _handle_notification_message(self, message: Message):
        """处理通知消息"""
        if message.type.value == "notification":
            # 接收到通知消息，自动发送
            payload = message.payload
            await self._send_notification({
                'type': payload.get('type', 'console'),
                'content': payload.get('content', ''),
                'metadata': payload.get('metadata', {}),
                'sender': message.sender
            })
    
    async def _send_notification(self, payload: Dict) -> Dict:
        """发送通知"""
        notification_type = payload.get('type', 'console')
        content = payload.get('content', '')
        metadata = payload.get('metadata', {})
        sender = payload.get('sender', 'system')
        
        if notification_type not in self.notification_types:
            raise ValueError(f"不支持的通知类型: {notification_type}")
        
        # 模拟发送延迟
        await asyncio.sleep(0.5)
        
        # 生成通知ID
        notification_id = f"notif_{datetime.now().strftime('%Y%m%d_%H%M%S')}"
        
        # 发送通知（模拟）
        if notification_type == 'console':
            print(f"\n[通知] {content}")
            self.logger.info(f"控制台通知已发送: {content}")
        elif notification_type == 'email':
            self.logger.info(f"邮件通知已发送: {content}")
        elif notification_type == 'sms':
            self.logger.info(f"短信通知已发送: {content}")
        elif notification_type == 'webhook':
            self.logger.info(f"Webhook通知已发送: {content}")
        
        # 保存到历史记录
        notification_record = {
            'notification_id': notification_id,
            'type': notification_type,
            'content': content,
            'metadata': metadata,
            'sender': sender,
            'sent_at': datetime.now().isoformat(),
            'status': 'sent'
        }
        
        self.notification_history.append(notification_record)
        
        # 限制历史记录大小
        if len(self.notification_history) > self.max_history:
            self.notification_history.pop(0)
        
        result = {
            'notification_id': notification_id,
            'type': notification_type,
            'content': content,
            'sent_at': datetime.now().isoformat(),
            'status': 'sent'
        }
        
        self.logger.info(f"通知已发送: {notification_id} ({notification_type})")
        
        return result
    
    async def _broadcast_notification(self, payload: Dict) -> Dict:
        """广播通知"""
        content = payload.get('content', '')
        notification_types = payload.get('types', ['console'])
        
        results = []
        for notif_type in notification_types:
            result = await self._send_notification({
                'type': notif_type,
                'content': content,
                'metadata': payload.get('metadata', {})
            })
            results.append(result)
        
        return {
            'broadcast_id': f"broadcast_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            'content': content,
            'types': notification_types,
            'results': results,
            'sent_at': datetime.now().isoformat()
        }
    
    async def _list_notifications(self, payload: Dict) -> Dict:
        """列出通知历史"""
        limit = payload.get('limit', 100)
        offset = payload.get('offset', 0)
        
        # 分页
        notifications = self.notification_history[offset:offset + limit]
        
        return {
            'notifications': notifications,
            'total': len(self.notification_history),
            'limit': limit,
            'offset': offset
        }
    
    async def _save_notification_history(self):
        """保存通知历史到文件"""
        history_file = self.notifications_dir / "history.json"
        
        try:
            with open(history_file, 'w', encoding='utf-8') as f:
                json.dump(self.notification_history, f, ensure_ascii=False, indent=2)
            
            self.logger.info(f"通知历史已保存: {history_file}")
        except Exception as e:
            self.logger.error(f"保存通知历史失败: {e}")
    
    async def _load_notification_history(self):
        """从文件加载通知历史"""
        history_file = self.notifications_dir / "history.json"
        
        if history_file.exists():
            try:
                with open(history_file, 'r', encoding='utf-8') as f:
                    self.notification_history = json.load(f)
                
                self.logger.info(f"通知历史已加载: {len(self.notification_history)} 条记录")
            except Exception as e:
                self.logger.error(f"加载通知历史失败: {e}")
