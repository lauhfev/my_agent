"""
调度器Agent - 负责任务分配和协调
"""
import asyncio
from typing import Dict, Any
from datetime import datetime
from apscheduler.schedulers.asyncio import AsyncIOScheduler
from apscheduler.triggers.cron import CronTrigger
from apscheduler.triggers.interval import IntervalTrigger

from .base_agent import BaseAgent, AgentStatus
from . import Task, TaskPriority, task_queue, message_bus, Message, MessageType
from . import get_logger


class SchedulerAgent(BaseAgent):
    """调度器Agent"""
    
    def __init__(self):
        super().__init__(
            name="scheduler",
            description="任务调度器Agent，负责任务分配和协调"
        )
        self.scheduler = AsyncIOScheduler()
        self.registered_agents = {}
        self.scheduled_tasks = {}
    
    async def initialize(self) -> None:
        """初始化调度器"""
        self.logger.info("调度器正在初始化...")
        
        # 启动调度器
        self.scheduler.start()
        
        # 注册默认任务处理器
        task_queue.register_handler("schedule_task", self._handle_schedule_task)
        task_queue.register_handler("cancel_scheduled_task", self._handle_cancel_scheduled)
        
        # 注册消息处理器
        message_bus.subscribe("agent.all", self._handle_agent_message)
        
        # 加载预定义任务
        await self._load_predefined_tasks()
        
        self.logger.info("调度器初始化完成")
    
    async def execute(self, task: Task) -> Dict:
        """执行调度任务"""
        self.logger.info(f"执行调度任务: {task.task_id}")
        
        result = {}
        
        if task.task_type == "schedule_task":
            result = await self._schedule_task(task.payload)
        elif task.task_type == "cancel_scheduled_task":
            result = await self._cancel_scheduled_task(task.payload)
        elif task.task_type == "list_scheduled_tasks":
            result = await self._list_scheduled_tasks()
        elif task.task_type == "list_agents":
            result = await self._list_agents()
        else:
            raise ValueError(f"未知的调度任务类型: {task.task_type}")
        
        return result
    
    async def shutdown(self) -> None:
        """关闭调度器"""
        self.logger.info("调度器正在关闭...")
        
        # 停止调度器
        if self.scheduler.running:
            self.scheduler.shutdown(wait=False)
        
        self.logger.info("调度器已关闭")
    
    async def _handle_schedule_task(self, task: Task) -> Dict:
        """处理任务调度请求"""
        return await self._schedule_task(task.payload)
    
    async def _handle_cancel_scheduled(self, task: Task) -> Dict:
        """处理取消调度请求"""
        return await self._cancel_scheduled_task(task.payload)
    
    async def _schedule_task(self, payload: Dict) -> Dict:
        """调度任务"""
        task_name = payload.get('task_name')
        agent_name = payload.get('agent_name')
        schedule_type = payload.get('schedule_type', 'interval')  # cron, interval, date
        schedule_config = payload.get('schedule_config', {})
        task_payload = payload.get('task_payload', {})
        
        if not task_name or not agent_name:
            raise ValueError("task_name和agent_name不能为空")
        
        # 创建调度任务
        if schedule_type == 'cron':
            trigger = CronTrigger(**schedule_config)
        elif schedule_type == 'interval':
            trigger = IntervalTrigger(**schedule_config)
        elif schedule_type == 'date':
            from apscheduler.triggers.date import DateTrigger
            trigger = DateTrigger(**schedule_config)
        else:
            raise ValueError(f"不支持的调度类型: {schedule_type}")
        
        # 添加任务到调度器
        job = self.scheduler.add_job(
            self._execute_scheduled_task,
            trigger=trigger,
            args=[agent_name, task_payload],
            id=task_name,
            replace_existing=True
        )
        
        self.scheduled_tasks[task_name] = {
            'job_id': job.id,
            'agent_name': agent_name,
            'schedule_type': schedule_type,
            'schedule_config': schedule_config,
            'task_payload': task_payload,
            'created_at': datetime.now().isoformat()
        }
        
        self.logger.info(f"任务已调度: {task_name} -> {agent_name} ({schedule_type})")
        
        return {
            'task_name': task_name,
            'job_id': job.id,
            'next_run_time': job.next_run_time.isoformat() if job.next_run_time else None
        }
    
    async def _cancel_scheduled_task(self, payload: Dict) -> Dict:
        """取消调度任务"""
        task_name = payload.get('task_name')
        
        if not task_name:
            raise ValueError("task_name不能为空")
        
        if task_name in self.scheduled_tasks:
            job = self.scheduler.get_job(task_name)
            if job:
                self.scheduler.remove_job(task_name)
            
            del self.scheduled_tasks[task_name]
            self.logger.info(f"调度任务已取消: {task_name}")
            
            return {'task_name': task_name, 'status': 'cancelled'}
        else:
            raise ValueError(f"调度任务不存在: {task_name}")
    
    async def _execute_scheduled_task(self, agent_name: str, task_payload: Dict):
        """执行调度任务"""
        self.logger.info(f"执行调度任务: {agent_name}")
        
        # 创建任务
        task = Task(
            priority=TaskPriority.NORMAL.value,
            created_at=datetime.now().isoformat(),
            task_id=f"scheduled_{datetime.now().strftime('%Y%m%d_%H%M%S')}",
            task_type="scheduled_task",
            agent_name=agent_name,
            payload=task_payload
        )
        
        # 添加到任务队列
        await task_queue.add_task(task)
        
        # 发送任务请求给目标Agent
        message = Message(
            sender=self.name,
            receiver=agent_name,
            msg_type=MessageType.TASK_REQUEST,
            payload=task.to_dict()
        )
        await message_bus.send_to_agent(message)
        
        self.logger.debug(f"调度任务已发送: {task.task_id} -> {agent_name}")
    
    async def _list_scheduled_tasks(self) -> Dict:
        """列出所有调度任务"""
        return {
            'scheduled_tasks': list(self.scheduled_tasks.values()),
            'count': len(self.scheduled_tasks)
        }
    
    async def _list_agents(self) -> Dict:
        """列出所有注册的Agent"""
        return {
            'agents': list(self.registered_agents.values()),
            'count': len(self.registered_agents)
        }
    
    async def _handle_agent_message(self, message: Message):
        """处理Agent消息"""
        if message.type.value == "status_update":
            agent_name = message.sender
            status = message.payload.get('status')
            self.registered_agents[agent_name] = {
                'name': agent_name,
                'status': status,
                'last_heartbeat': message.payload.get('last_heartbeat')
            }
            self.logger.debug(f"Agent状态更新: {agent_name} -> {status}")
    
    async def _load_predefined_tasks(self):
        """加载预定义任务"""
        try:
            from core.config_manager import config_manager
            
            tasks_config = config_manager.get('tasks', {})
            
            for task_config in tasks_config.get('scheduled_tasks', []):
                await self._schedule_task(task_config)
                self.logger.info(f"预定义任务已加载: {task_config.get('task_name')}")
        except Exception as e:
            self.logger.warning(f"加载预定义任务失败: {e}")
