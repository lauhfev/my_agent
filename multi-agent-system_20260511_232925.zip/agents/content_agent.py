"""
内容生成Agent - 自动生成运营内容
"""
import asyncio
import random
from typing import Dict, Any
from datetime import datetime

from .base_agent import BaseAgent, AgentStatus
from . import Task, task_queue, message_bus, Message, MessageType
from . import get_logger


class ContentAgent(BaseAgent):
    """内容生成Agent"""
    
    def __init__(self):
        super().__init__(
            name="content",
            description="内容生成Agent，自动生成运营内容"
        )
        self.content_types = ['post', 'article', 'email', 'notification']
        self.templates = {
            'post': [
                "今天想和大家分享一个好消息！我们的{product}获得了用户的一致好评。{emoji}",
                "本周特惠来啦！{product}限时折扣，不要错过哦~ {emoji}",
                "感谢大家的支持！{product}销量突破{count}，继续加油！{emoji}"
            ],
            'article': [
                "# {title}\n\n本文介绍了{product}的核心功能和优势...",
                "# {title}\n\n深入了解{product}的技术架构和设计理念...",
                "# {title}\n\n{product}在各行业的应用案例分享..."
            ],
            'email': [
                "亲爱的用户，感谢您使用{product}。本周我们为您准备了特别优惠...",
                "您好！{product}已更新到最新版本，新增了多项功能...",
                "邀请您参加{product}线上交流会，与专家面对面交流..."
            ],
            'notification': [
                "{product}有新的动态，点击查看详情",
                "您的{product}订单已发货，预计{days}天到达",
                "{product}维护已完成，所有功能已恢复正常"
            ]
        }
    
    async def initialize(self) -> None:
        """初始化内容生成Agent"""
        self.logger.info("内容生成Agent正在初始化...")
        
        # 注册任务处理器
        task_queue.register_handler("generate_content", self._handle_generate_content)
        task_queue.register_handler("schedule_content", self._handle_schedule_content)
        
        self.logger.info("内容生成Agent初始化完成")
    
    async def execute(self, task: Task) -> Dict:
        """执行内容生成任务"""
        self.logger.info(f"执行内容生成任务: {task.task_id}")
        
        result = {}
        task_type = task.task_type
        
        if task_type == "generate_content":
            result = await self._generate_content(task.payload)
        elif task_type == "schedule_content":
            result = await self._schedule_content(task.payload)
        else:
            # 处理直接任务
            content_type = task.payload.get('content_type', 'post')
            result = await self._generate_content(task.payload)
        
        return result
    
    async def shutdown(self) -> None:
        """关闭内容生成Agent"""
        self.logger.info("内容生成Agent正在关闭...")
        self.logger.info("内容生成Agent已关闭")
    
    async def _handle_generate_content(self, task: Task) -> Dict:
        """处理内容生成请求"""
        return await self._generate_content(task.payload)
    
    async def _handle_schedule_content(self, task: Task) -> Dict:
        """处理内容调度请求"""
        return await self._schedule_content(task.payload)
    
    async def _generate_content(self, payload: Dict) -> Dict:
        """生成内容"""
        content_type = payload.get('content_type', 'post')
        product = payload.get('product', '产品')
        emoji = payload.get('emoji', '🎉')
        count = payload.get('count', 100)
        title = payload.get('title', f'{product}介绍')
        days = payload.get('days', 3)
        
        # 模拟内容生成延迟
        await asyncio.sleep(1)
        
        # 选择模板
        templates = self.templates.get(content_type, self.templates['post'])
        template = random.choice(templates)
        
        # 填充模板
        content = template.format(
            product=product,
            emoji=emoji,
            count=count,
            title=title,
            days=days
        )
        
        # 生成结果
        result = {
            'content_type': content_type,
            'content': content,
            'generated_at': datetime.now().isoformat(),
            'word_count': len(content),
            'metadata': {
                'product': product,
                'template_used': template[:50] + '...' if len(template) > 50 else template
            }
        }
        
        self.logger.info(f"内容已生成: {content_type} - {len(content)}字符")
        
        # 发送通知
        await self.send_notification(
            content=f"内容已生成: {content_type}",
            metadata={'content_id': result['generated_at']}
        )
        
        return result
    
    async def _schedule_content(self, payload: Dict) -> Dict:
        """调度内容生成任务"""
        # 这里可以调用scheduler agent来调度内容生成
        # 简单实现：直接生成内容
        return await self._generate_content(payload)
